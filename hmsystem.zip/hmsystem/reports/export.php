<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_functions.php';
requireLogin();

$conn = getDBConnection();
$report_type = $_GET['report'] ?? 'patients';
if ($report_type === 'payments') {
    $report_type = 'billing';
}
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to = $_GET['date_to'] ?? date('Y-m-d');
$filter_pid = intval($_GET['patient_id'] ?? 0);
$filter_status = $_GET['status'] ?? '';
$filter_dept = intval($_GET['dept'] ?? 0);

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $report_type . '_report_' . date('Y-m-d') . '.csv"');

$output = fopen('php://output', 'w');
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM for Excel

switch ($report_type) {
    case 'patients':
        fputcsv($output, ['Patient ID','First Name','Last Name','Gender','Date of Birth','Contact Number','Email','Blood Type','Registration Date']);
        $where = "WHERE registration_date BETWEEN ? AND ?"; $params=[$date_from,$date_to]; $types='ss';
        $stmt=$conn->prepare("SELECT * FROM patients $where ORDER BY registration_date DESC");
        $stmt->bind_param($types,...$params); $stmt->execute();
        $rows=$stmt->get_result();
        while ($r=$rows->fetch_assoc()) {
            fputcsv($output,[$r['patient_id'],$r['first_name'],$r['last_name'],$r['gender'],$r['date_of_birth'],$r['contact_number'],$r['email'],$r['blood_type'],$r['registration_date']]);
        }
        break;

    case 'appointments':
        fputcsv($output, ['Appointment ID','Patient','Patient ID','Department','Doctor','Date','Time','Purpose','Status']);
        $where = "WHERE a.appointment_date BETWEEN ? AND ?"; $params=[$date_from,$date_to]; $types='ss';
        if ($filter_status) { $where.=" AND a.status=?"; $params[]=$filter_status; $types.='s'; }
        if ($filter_dept) { $where.=" AND a.department_id=?"; $params[]=$filter_dept; $types.='i'; }
        if ($filter_pid) { $where.=" AND a.patient_id=?"; $params[]=$filter_pid; $types.='i'; }
        $stmt=$conn->prepare("SELECT a.appointment_id,CONCAT(p.first_name,' ',p.last_name) as pn,p.patient_id as pid,d.name as dname,a.doctor_name,a.appointment_date,a.appointment_time,a.purpose,a.status FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN departments d ON a.department_id=d.id $where ORDER BY a.appointment_date DESC");
        $stmt->bind_param($types,...$params); $stmt->execute();
        $rows=$stmt->get_result();
        while ($r=$rows->fetch_assoc()) {
            fputcsv($output,[$r['appointment_id'],$r['pn'],$r['pid'],$r['dname'],$r['doctor_name'],$r['appointment_date'],$r['appointment_time'],$r['purpose'],$r['status']]);
        }
        break;

    case 'medical_records':
        fputcsv($output, ['Record ID','Patient','Patient ID','Date','Attending Staff','Diagnosis']);
        $where = "WHERE mr.record_date BETWEEN ? AND ?"; $params=[$date_from,$date_to]; $types='ss';
        if ($filter_pid) { $where .= " AND mr.patient_id=?"; $params[]=$filter_pid; $types.='i'; }
        $stmt = $conn->prepare("SELECT mr.record_id, CONCAT(p.first_name,' ',p.last_name) as pn, p.patient_id as pid, mr.record_date, u.full_name as staff_name, mr.diagnosis FROM medical_records mr JOIN patients p ON mr.patient_id=p.id LEFT JOIN users u ON mr.attending_staff=u.id $where ORDER BY mr.record_date DESC");
        $stmt->bind_param($types,...$params); $stmt->execute();
        $rows=$stmt->get_result();
        while ($r=$rows->fetch_assoc()) {
            fputcsv($output,[$r['record_id'],$r['pn'],$r['pid'],$r['record_date'],$r['staff_name']??'',$r['diagnosis']??'']);
        }
        break;

    case 'billing':
        // SECTION 1: INVOICES
        fputcsv($output, ['--- PATIENT BILLS / INVOICES ---']);
        fputcsv($output, ['Bill ID','Patient','Patient ID','Bill Date','Total Amount','Amount Paid','Balance','Status']);
        $where_b = "WHERE b.bill_date BETWEEN ? AND ?"; $params_b=[$date_from,$date_to]; $types_b='ss';
        if ($filter_status) { $where_b.=" AND b.payment_status=?"; $params_b[]=$filter_status; $types_b.='s'; }
        if ($filter_pid) { $where_b.=" AND b.patient_id=?"; $params_b[]=$filter_pid; $types_b.='i'; }
        $stmt_b=$conn->prepare("SELECT b.bill_id,CONCAT(p.first_name,' ',p.last_name) as pn,p.patient_id as pid,b.bill_date,b.total_amount,b.amount_paid,b.balance,b.payment_status FROM bills b JOIN patients p ON b.patient_id=p.id $where_b ORDER BY b.bill_date DESC");
        $stmt_b->bind_param($types_b,...$params_b); $stmt_b->execute();
        $rows_b=$stmt_b->get_result();
        while ($r=$rows_b->fetch_assoc()) {
            fputcsv($output,[$r['bill_id'],$r['pn'],$r['pid'],$r['bill_date'],$r['total_amount'],$r['amount_paid'],$r['balance'],$r['payment_status']]);
        }

        // Blank separator
        fputcsv($output, []);
        fputcsv($output, ['--- PAYMENT COLLECTIONS & SUKLI ---']);
        fputcsv($output, ['Payment ID','Bill ID','Patient','Patient ID','Payment Date','Amount Paid','Cash Received','Sukli (Change)','Method','Reference #','Received By']);
        $where_p = "WHERE py.payment_date BETWEEN ? AND ?"; $params_p=[$date_from,$date_to]; $types_p='ss';
        if ($filter_pid) { $where_p .= " AND py.patient_id=?"; $params_p[]=$filter_pid; $types_p.='i'; }
        $stmt_p=$conn->prepare("SELECT py.payment_id,b.bill_id,CONCAT(p.first_name,' ',p.last_name) as pn,p.patient_id as pid,py.payment_date,py.amount_paid,py.cash_tendered,py.change_amount,py.payment_method,py.reference_number,u.full_name as rby FROM payments py JOIN patients p ON py.patient_id=p.id JOIN bills b ON py.bill_id=b.id LEFT JOIN users u ON py.received_by=u.id $where_p ORDER BY py.payment_date DESC");
        $stmt_p->bind_param($types_p,...$params_p); $stmt_p->execute();
        $rows_p=$stmt_p->get_result();
        while ($r=$rows_p->fetch_assoc()) {
            fputcsv($output,[$r['payment_id'],$r['bill_id'],$r['pn'],$r['pid'],$r['payment_date'],$r['amount_paid'],$r['cash_tendered']?:$r['amount_paid'],$r['change_amount']??0,$r['payment_method'],$r['reference_number']??'',$r['rby']??'']);
        }
        break;
}

fclose($output);
$conn->close();
exit();
?>
