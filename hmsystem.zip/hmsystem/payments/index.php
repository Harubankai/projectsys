<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_functions.php';
requireLogin();
requireNonDoctor(); // Doctors cannot access billing/payments

// Unified with Billing: redirect to the Payments tab inside Billing & Payments
$params = $_GET;
if (!isset($params['tab'])) {
    $params['tab'] = 'payments';
}
header("Location: /hmsystem/billing/index.php?" . http_build_query($params));
exit();
