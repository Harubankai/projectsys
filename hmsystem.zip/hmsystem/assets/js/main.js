document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const toggleBtn = document.getElementById('mobileSidebarToggle');
    const overlay = document.getElementById('sidebarOverlay');

    // ──────────────────────────────────────────────
    //  Sidebar open / close (mobile)
    // ──────────────────────────────────────────────
    function openSidebar() {
        if (sidebar) sidebar.classList.add('active');
        if (overlay) overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        if (sidebar) sidebar.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    if (toggleBtn) {
        toggleBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            sidebar && sidebar.classList.contains('active') ? closeSidebar() : openSidebar();
        });
    }

    if (overlay) overlay.addEventListener('click', closeSidebar);

    window.addEventListener('resize', function() {
        if (window.innerWidth > 1024) closeSidebar();
    });

    document.querySelectorAll('.sidebar-link').forEach(function(link) {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 1024) closeSidebar();
        });
    });

    // ──────────────────────────────────────────────
    //  Logout Confirmation Modal
    // ──────────────────────────────────────────────
    const logoutModal   = document.getElementById('logoutModal');
    const logoutBtn     = document.getElementById('sidebarLogoutBtn');
    const cancelBtn     = document.getElementById('logoutCancelBtn');

    function openLogoutModal() {
        if (logoutModal) {
            logoutModal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeLogoutModal() {
        if (logoutModal) {
            logoutModal.classList.remove('active');
            document.body.style.overflow = '';
        }
    }

    if (logoutBtn)  logoutBtn.addEventListener('click', openLogoutModal);
    if (cancelBtn)  cancelBtn.addEventListener('click', closeLogoutModal);

    // Click backdrop to close
    if (logoutModal) {
        logoutModal.addEventListener('click', function(e) {
            if (e.target === logoutModal) closeLogoutModal();
        });
    }

    // Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeSidebar();
            closeLogoutModal();
        }
    });

    // ──────────────────────────────────────────────
    //  Global Password Field Eye Icon Toggle
    // ──────────────────────────────────────────────
    document.addEventListener('click', function(e) {
        const toggleIcon = e.target.closest('.password-toggle-icon');
        if (toggleIcon) {
            const targetId = toggleIcon.getAttribute('data-target');
            let input = targetId ? document.getElementById(targetId) : null;
            if (!input) {
                const wrapper = toggleIcon.closest('.password-field-wrapper');
                if (wrapper) {
                    input = wrapper.querySelector('input');
                }
            }

            if (input) {
                if (input.type === 'password') {
                    input.type = 'text';
                    toggleIcon.classList.remove('fa-eye');
                    toggleIcon.classList.add('fa-eye-slash');
                } else {
                    input.type = 'password';
                    toggleIcon.classList.remove('fa-eye-slash');
                    toggleIcon.classList.add('fa-eye');
                }
            }
        }
    });

    // ──────────────────────────────────────────────
    //  Auto Popout & Dismiss for Success / Action Alerts
    // ──────────────────────────────────────────────
    document.querySelectorAll('.alert-success').forEach(function(alert) {
        if (!alert.querySelector('.alert-close-btn')) {
            const closeBtn = document.createElement('button');
            closeBtn.className = 'alert-close-btn';
            closeBtn.innerHTML = '&times;';
            closeBtn.setAttribute('title', 'Dismiss');
            closeBtn.style.cssText = 'background:none;border:none;font-size:20px;cursor:pointer;margin-left:auto;color:inherit;opacity:0.65;padding:0 6px;line-height:1;transition:opacity 0.2s;';
            closeBtn.onmouseenter = function() { closeBtn.style.opacity = '1'; };
            closeBtn.onmouseleave = function() { closeBtn.style.opacity = '0.65'; };
            closeBtn.onclick = function() {
                alert.style.transition = 'all 0.35s cubic-bezier(0.16, 1, 0.3, 1)';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-12px) scale(0.97)';
                setTimeout(function() { if (alert.parentNode) alert.remove(); }, 350);
            };
            alert.appendChild(closeBtn);
        }

        // Auto dismiss after 5 seconds
        setTimeout(function() {
            if (alert && alert.parentNode) {
                alert.style.transition = 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)';
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-12px) scale(0.97)';
                setTimeout(function() { if (alert.parentNode) alert.remove(); }, 400);
            }
        }, 5000);
    });

    // ──────────────────────────────────────────────
    //  Auto-Submit on Filter Bar Dropdown Change
    // ──────────────────────────────────────────────
    document.querySelectorAll('.filter-bar select, .filter-bar input[type="date"]').forEach(function(filterControl) {
        filterControl.addEventListener('change', function() {
            if (filterControl.form) {
                // If there is an instant table on page, hide non-matching rows immediately
                const selectedVal = (filterControl.value || '').trim().toLowerCase();
                const table = document.querySelector('.table-wrapper table tbody');
                if (table && selectedVal && filterControl.name === 'status') {
                    const rows = table.querySelectorAll('tr');
                    rows.forEach(function(r) {
                        const rowText = (r.textContent || '').toLowerCase();
                        if (!rowText.includes(selectedVal)) {
                            r.style.display = 'none';
                        }
                    });
                }
                filterControl.form.submit();
            }
        });
    });

    // ──────────────────────────────────────────────
    //  Modal Update / Save Button Visual State
    // ──────────────────────────────────────────────
    document.querySelectorAll('.modal-overlay form, .modal form').forEach(function(form) {
        form.addEventListener('submit', function() {
            if (form.checkValidity()) {
                const submitBtn = form.querySelector('button[type="submit"]');
                if (submitBtn && !submitBtn.disabled) {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
                }
            }
        });
    });
});


