<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_functions.php';
requireLogin();
requireNonDoctor(); // Doctors cannot access billing and payments

$conn = getDBConnection();
$page_title = 'Billing & Payments';
$page_subtitle = 'Manage patient invoices, charges, and payment records';
$page_active = 'billing';

$message = ''; $error = '';
if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}

$action = $_GET['action'] ?? '';
$bill_db_id = intval($_GET['id'] ?? 0);
$filter_pid = intval($_GET['patient_id'] ?? 0);
$tab = $_GET['tab'] ?? 'bills'; // 'bills' or 'payments'

// Patients for dropdown
$pts = $conn->query("SELECT id, patient_id, CONCAT(first_name,' ',last_name) as full_name FROM patients ORDER BY first_name");
$pt_list = [];
while ($p = $pts->fetch_assoc()) $pt_list[$p['id']] = $p['patient_id'] . ' - ' . $p['full_name'];

$is_patient = isPatient();
$my_patient_id = getPatientId();
if ($is_patient && !$my_patient_id && !empty($_SESSION['username'])) {
    $p_stmt = $conn->prepare("SELECT id FROM patients WHERE email = ? OR contact_number = ? LIMIT 1");
    $p_stmt->bind_param("ss", $_SESSION['username'], $_SESSION['username']);
    $p_stmt->execute();
    if ($p_res = $p_stmt->get_result()->fetch_assoc()) {
        $my_patient_id = $p_res['id'];
        $_SESSION['patient_id'] = $my_patient_id;
    }
    $p_stmt->close();
}

// DELETE bill
if ($action === 'delete' && $bill_db_id && !$is_patient) {
    $stmt = $conn->prepare("DELETE FROM bills WHERE id=?");
    $stmt->bind_param("i",$bill_db_id); $stmt->execute(); $stmt->close();
    logActivity($conn, $_SESSION['user_id'], 'Bill Deleted', "Deleted bill ID: $bill_db_id");
    $_SESSION['flash_message'] = 'Bill deleted successfully.';
    header("Location: /hmsystem/billing/index.php?tab=bills");
    exit();
}

// CREATE BILL
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_action']??'') === 'add' && !$is_patient) {
    $new_id = generateID('BILL', 'bills', 'bill_id', $conn);
    $pid = intval($_POST['patient_id']);
    $date = $_POST['bill_date'];
    $notes = trim($_POST['notes']);
    $uid = $_SESSION['user_id'];

    $descriptions = $_POST['desc'] ?? [];
    $service_types = $_POST['service_type'] ?? [];
    $quantities = $_POST['qty'] ?? [];
    $prices = $_POST['price'] ?? [];

    if (!$pid || !$date || empty($descriptions)) {
        $error = 'Please fill in all required fields and add at least one item.';
    } else {
        $total = 0;
        $items = [];
        foreach ($descriptions as $i => $desc) {
            if (!trim($desc)) continue;
            $qty = max(1, intval($quantities[$i]));
            $price = floatval($prices[$i]);
            $sub = $qty * $price;
            $total += $sub;
            $items[] = [trim($desc), $service_types[$i] ?? '', $qty, $price, $sub];
        }

        $stmt = $conn->prepare("INSERT INTO bills (bill_id,patient_id,bill_date,total_amount,amount_paid,balance,payment_status,notes,created_by) VALUES (?,?,?,?,0,?,?,?,?)");
        $status = 'Unpaid';
        $stmt->bind_param("sisddssi",$new_id,$pid,$date,$total,$total,$status,$notes,$uid);
        if ($stmt->execute()) {
            $bid = $conn->insert_id;
            $item_stmt = $conn->prepare("INSERT INTO bill_items (bill_id,description,service_type,quantity,unit_price,subtotal) VALUES (?,?,?,?,?,?)");
            foreach ($items as $item) {
                $item_stmt->bind_param("issids", $bid, $item[0], $item[1], $item[2], $item[3], $item[4]);
                $item_stmt->execute();
            }
            $item_stmt->close();
            $pname = $pt_list[$pid] ?? "Patient #$pid";
            logActivity($conn, $uid, 'Bill Created', "Created bill $new_id for $pname, total: ".number_format($total,2));
            $_SESSION['flash_message'] = "Bill $new_id created successfully. Total: ₱" . number_format($total, 2);
            header("Location: /hmsystem/billing/index.php?tab=bills");
            exit();
        } else { $error = 'Error creating bill.'; }
        $stmt->close();
    }
}

// RECORD PAYMENT (WITH SUKLI / CHANGE CALCULATION)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_action']??'') === 'pay' && !$is_patient) {
    $new_id = generateID('PAY', 'payments', 'payment_id', $conn);
    $bid = intval($_POST['bill_id']);
    $amount = floatval($_POST['amount_paid']);
    $cash_tendered = floatval($_POST['cash_tendered'] ?? 0);
    $method = $_POST['payment_method'];
    $ref = trim($_POST['reference_number'] ?? '');
    $date = $_POST['payment_date'];
    $notes = trim($_POST['notes'] ?? '');
    $uid = $_SESSION['user_id'];

    // Get bill info
    $bill_s = $conn->prepare("SELECT * FROM bills WHERE id=?");
    $bill_s->bind_param("i",$bid); $bill_s->execute();
    $bill_row = $bill_s->get_result()->fetch_assoc(); $bill_s->close();

    if (!$bill_row) {
        $error = 'Bill not found.';
    } elseif ($amount <= 0) {
        $error = 'Amount must be greater than zero.';
    } elseif ($amount > $bill_row['balance'] + 0.01) {
        $error = 'Amount paid cannot exceed the remaining balance (₱' . number_format($bill_row['balance'],2) . ').';
    } elseif ($method === 'Cash' && $cash_tendered > 0 && $cash_tendered < $amount - 0.01) {
        $error = 'Cash received (₱' . number_format($cash_tendered,2) . ') cannot be less than the amount to pay (₱' . number_format($amount,2) . ').';
    } else {
        if ($cash_tendered <= 0) {
            $cash_tendered = $amount;
        }
        $change_amount = max(0.00, $cash_tendered - $amount);
        $pid = $bill_row['patient_id'];

        $stmt = $conn->prepare("INSERT INTO payments (payment_id,bill_id,patient_id,payment_date,amount_paid,cash_tendered,change_amount,payment_method,reference_number,received_by,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("siisdddssis",$new_id,$bid,$pid,$date,$amount,$cash_tendered,$change_amount,$method,$ref,$uid,$notes);
        if ($stmt->execute()) {
            // Update bill
            $new_paid = $bill_row['amount_paid'] + $amount;
            $new_balance = max(0, $bill_row['total_amount'] - $new_paid);
            $new_status = $new_balance <= 0.001 ? 'Paid' : 'Partially Paid';
            $upd = $conn->prepare("UPDATE bills SET amount_paid=?,balance=?,payment_status=? WHERE id=?");
            $upd->bind_param("ddsi",$new_paid,$new_balance,$new_status,$bid);
            $upd->execute(); $upd->close();

            $pname = $pt_list[$pid] ?? "Patient #$pid";
            $sukli_msg = ($method === 'Cash' && $change_amount > 0) ? " | Sukli (Change): ₱" . number_format($change_amount, 2) : "";
            logActivity($conn, $uid, 'Payment Recorded', "Recorded payment $new_id of ₱".number_format($amount,2)." for bill {$bill_row['bill_id']}$sukli_msg");
            $_SESSION['flash_message'] = "Payment $new_id of ₱" . number_format($amount,2) . " recorded successfully. Cash Received: ₱" . number_format($cash_tendered, 2) . "$sukli_msg. Bill status: $new_status.";
            header("Location: /hmsystem/billing/index.php?tab=payments");
            exit();
        } else {
            $error = 'Error recording payment: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Unpaid/partial bills for payment modal
$unpaid_bills_q = $conn->query("SELECT b.id, b.bill_id, b.balance, b.total_amount, CONCAT(p.first_name,' ',p.last_name) as pname, p.patient_id as pid FROM bills b JOIN patients p ON b.patient_id=p.id WHERE b.payment_status IN ('Unpaid','Partially Paid') ORDER BY b.bill_date DESC");
$unpaid_bills = [];
while ($ub = $unpaid_bills_q->fetch_assoc()) {
    $unpaid_bills[$ub['id']] = $ub;
}

// Catalogue of standard services for automatic pricing
$service_catalogue = [
    ['name' => 'General Medical Consultation', 'type' => 'Consultation', 'price' => 500.00],
    ['name' => 'Specialist / Follow-up Consultation', 'type' => 'Consultation', 'price' => 800.00],
    ['name' => 'Pediatric Consultation', 'type' => 'Consultation', 'price' => 500.00],
    ['name' => 'Complete Blood Count (CBC)', 'type' => 'Laboratory', 'price' => 350.00],
    ['name' => 'Urinalysis', 'type' => 'Laboratory', 'price' => 200.00],
    ['name' => 'Fecalysis', 'type' => 'Laboratory', 'price' => 200.00],
    ['name' => 'Fasting Blood Sugar (FBS)', 'type' => 'Laboratory', 'price' => 250.00],
    ['name' => 'Lipid Profile', 'type' => 'Laboratory', 'price' => 800.00],
    ['name' => 'Chest X-Ray (PA View)', 'type' => 'Radiology', 'price' => 500.00],
    ['name' => '12-Lead ECG Examination', 'type' => 'Procedure', 'price' => 500.00],
    ['name' => 'Nebulization Therapy', 'type' => 'Procedure', 'price' => 250.00],
    ['name' => 'Wound Dressing & Cleaning', 'type' => 'Procedure', 'price' => 350.00],
    ['name' => 'Dental Cleaning (Prophylaxis)', 'type' => 'Dental', 'price' => 800.00],
    ['name' => 'Tooth Extraction', 'type' => 'Dental', 'price' => 1000.00],
    ['name' => 'Room Accommodation (Per Day)', 'type' => 'Accommodation', 'price' => 1200.00],
    ['name' => 'Standard Medicine Package', 'type' => 'Medicine', 'price' => 300.00],
];

// Query for Bills
$search = trim($_GET['search'] ?? '');
$filter_status = $_GET['status'] ?? '';
$where_bills = "WHERE 1=1"; $params_b = []; $types_b = '';
if ($is_patient) {
    $where_bills .= " AND b.patient_id=?";
    $params_b[] = $my_patient_id ?: 0; $types_b .= 'i';
} elseif ($filter_pid) {
    $where_bills .= " AND b.patient_id=?";
    $params_b[] = $filter_pid; $types_b .= 'i';
}
if ($search) {
    $s="%$search%";
    $where_bills .= " AND (b.bill_id LIKE ? OR CONCAT(p.first_name,' ',p.last_name) LIKE ?)";
    $params_b = array_merge($params_b, [$s,$s]); $types_b .= 'ss';
}
if ($filter_status) {
    $where_bills .= " AND b.payment_status=?";
    $params_b[] = $filter_status; $types_b .= 's';
}

$per_page = 12; $page_num = max(1,intval($_GET['page']??1)); $offset = ($page_num-1)*$per_page;
$cq = $conn->prepare("SELECT COUNT(*) as cnt FROM bills b JOIN patients p ON b.patient_id=p.id $where_bills");
if ($types_b) $cq->bind_param($types_b,...$params_b);
$cq->execute();
$total_rows_b = $cq->get_result()->fetch_assoc()['cnt']; $total_pages_b = ceil($total_rows_b/$per_page); $cq->close();

$ap = $params_b; $ap[] = $per_page; $ap[] = $offset; $at = $types_b . 'ii';
$stmt_b = $conn->prepare("SELECT b.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_id as pid,
    COALESCE((SELECT SUM(change_amount) FROM payments WHERE bill_id = b.id), 0) AS total_sukli
    FROM bills b JOIN patients p ON b.patient_id=p.id $where_bills ORDER BY b.created_at DESC LIMIT ? OFFSET ?");
$stmt_b->bind_param($at,...$ap); $stmt_b->execute();
$bills = $stmt_b->get_result(); $stmt_b->close();

// Query for Payments
$where_pay = "WHERE 1=1"; $params_p = []; $types_p = '';
if ($is_patient) {
    $where_pay .= " AND py.patient_id=?";
    $params_p[] = $my_patient_id ?: 0; $types_p .= 'i';
} elseif ($filter_pid) {
    $where_pay .= " AND py.patient_id=?";
    $params_p[] = $filter_pid; $types_p .= 'i';
}
if ($search) {
    $s="%$search%";
    $where_pay .= " AND (py.payment_id LIKE ? OR CONCAT(p.first_name,' ',p.last_name) LIKE ? OR b.bill_id LIKE ?)";
    $params_p = array_merge($params_p, [$s,$s,$s]); $types_p .= 'sss';
}
$cq_p = $conn->prepare("SELECT COUNT(*) as cnt FROM payments py JOIN patients p ON py.patient_id=p.id JOIN bills b ON py.bill_id=b.id $where_pay");
if ($types_p) $cq_p->bind_param($types_p,...$params_p);
$cq_p->execute();
$total_rows_p = $cq_p->get_result()->fetch_assoc()['cnt']; $total_pages_p = ceil($total_rows_p/$per_page); $cq_p->close();

$ap_p = $params_p; $ap_p[] = $per_page; $ap_p[] = $offset; $at_p = $types_p . 'ii';
$stmt_p = $conn->prepare("SELECT py.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_id as pid, b.bill_id as bill_ref, b.total_amount as bill_total, u.full_name as received_by_name FROM payments py JOIN patients p ON py.patient_id=p.id JOIN bills b ON py.bill_id=b.id LEFT JOIN users u ON py.received_by=u.id $where_pay ORDER BY py.created_at DESC LIMIT ? OFFSET ?");
$stmt_p->bind_param($at_p,...$ap_p); $stmt_p->execute();
$payments = $stmt_p->get_result(); $stmt_p->close();

// View single bill details
$view_bill = null; $bill_items_list = []; $bill_payments = [];
if (in_array($action,['view']) && $bill_db_id) {
    $s = $conn->prepare("SELECT b.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_id as pid, u.full_name as created_by_name,
        COALESCE((SELECT SUM(change_amount) FROM payments WHERE bill_id = b.id), 0) AS total_sukli
        FROM bills b JOIN patients p ON b.patient_id=p.id LEFT JOIN users u ON b.created_by=u.id WHERE b.id=?");
    $s->bind_param("i",$bill_db_id); $s->execute();
    $view_bill = $s->get_result()->fetch_assoc(); $s->close();

    $si = $conn->prepare("SELECT * FROM bill_items WHERE bill_id=? ORDER BY id");
    $si->bind_param("i",$bill_db_id); $si->execute();
    $bill_items_list = $si->get_result()->fetch_all(MYSQLI_ASSOC); $si->close();

    $sp = $conn->prepare("SELECT py.*, u.full_name as received_by_name FROM payments py LEFT JOIN users u ON py.received_by=u.id WHERE py.bill_id=? ORDER BY py.payment_date DESC, py.id DESC");
    $sp->bind_param("i",$bill_db_id); $sp->execute();
    $bill_payments = $sp->get_result()->fetch_all(MYSQLI_ASSOC); $sp->close();
}

$status_colors = ['Unpaid'=>'danger','Partially Paid'=>'warning','Paid'=>'success'];
$prefill_patient_id = intval($_GET['patient_id'] ?? 0);
$prefill_doctor = trim($_GET['doctor'] ?? '');
$is_autobill = ($action === 'autobill');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing & Payments - Gerona Hospital</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="/hmsystem/assets/css/style.css?v=<?= filemtime(__DIR__ . '/../assets/css/style.css') ?>">
    <style>
        .finance-tabs { display: flex; gap: 8px; margin-bottom: 20px; border-bottom: 2px solid var(--border-color); padding-bottom: 4px; }
        .finance-tab { padding: 10px 20px; font-weight: 600; font-size: 14.5px; border-radius: 8px 8px 0 0; color: var(--text-muted); text-decoration: none; display: flex; align-items: center; gap: 8px; transition: all 0.2s; }
        .finance-tab:hover { color: var(--primary); background: var(--bg-cream-box); }
        .finance-tab.active { color: var(--primary); border-bottom: 3px solid var(--primary); background: var(--bg-cream-box); font-weight: 700; }
        .sukli-card { background: #ecfdf5; border: 2px dashed #059669; border-radius: 10px; padding: 14px 18px; margin: 12px 0; display: flex; align-items: center; justify-content: space-between; }
        .sukli-label { font-size: 13px; text-transform: uppercase; font-weight: 700; color: #047857; letter-spacing: 0.5px; }
        .sukli-value { font-size: 26px; font-weight: 800; color: #059669; }
        .quick-cash-btn { background: #fff; border: 1px solid #d1d5db; padding: 5px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.15s; }
        .quick-cash-btn:hover { background: var(--primary); color: #fff; border-color: var(--primary); }
    </style>
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="main-content">
        <?php include __DIR__ . '/../includes/header.php'; ?>
        <div class="page-body">
            <?php if ($message): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?=htmlspecialchars($message)?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?=htmlspecialchars($error)?></div><?php endif; ?>

            <!-- TAB CONTROLS -->
            <div class="finance-tabs">
                <a href="?tab=bills" class="finance-tab <?=$tab==='bills'?'active':''?>">
                    <i class="fas fa-file-invoice-dollar"></i> Bills & Invoices (<?=number_format($total_rows_b)?>)
                </a>
                <a href="?tab=payments" class="finance-tab <?=$tab==='payments'?'active':''?>">
                    <i class="fas fa-money-bill-wave"></i> Payment Records (<?=number_format($total_rows_p)?>)
                </a>
            </div>

            <?php if ($tab === 'bills'): ?>
            <!-- BILLS SECTION -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-file-invoice"></i> Invoices & Billing Records</h3>
                    <?php if (!$is_patient): ?>
                    <div style="display:flex;gap:10px;">
                        <button class="btn btn-outline" onclick="openAutoBillModal()">
                            <i class="fas fa-bolt text-warning"></i> Automatic Billing
                        </button>
                        <button class="btn btn-primary" onclick="openModal('addModal')">
                            <i class="fas fa-plus"></i> Create New Bill
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-body" style="padding-bottom:0;">
                    <form method="GET" class="filter-bar">
                        <input type="hidden" name="tab" value="bills">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" name="search" placeholder="Search bill ID, patient name..." value="<?=htmlspecialchars($search)?>">
                        </div>
                        <select name="status" class="form-control" style="width:160px;" onchange="this.form.submit()">
                            <option value="">All Status</option>
                            <option value="Unpaid" <?=$filter_status==='Unpaid'?'selected':''?>>Unpaid</option>
                            <option value="Partially Paid" <?=$filter_status==='Partially Paid'?'selected':''?>>Partially Paid</option>
                            <option value="Paid" <?=$filter_status==='Paid'?'selected':''?>>Paid</option>
                        </select>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                        <a href="/hmsystem/billing/index.php?tab=bills" class="btn btn-secondary"><i class="fas fa-times"></i> Clear</a>
                    </form>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead><tr>
                            <th>Bill ID</th><th>Patient</th><th>Bill Date</th><th>Total Amount</th>
                            <th>Amount Paid</th><th>Balance</th><th>Sukli (Change)</th><th>Status</th><th>Actions</th>
                        </tr></thead>
                        <tbody>
                        <?php if ($bills->num_rows===0): ?>
                        <tr><td colspan="9"><div class="empty-state"><i class="fas fa-file-invoice"></i><h4>No billing records found</h4><p>Create a bill or adjust your search filter.</p></div></td></tr>
                        <?php else: while ($b=$bills->fetch_assoc()): ?>
                        <tr>
                            <td><span class="fw-600 text-primary"><?=htmlspecialchars($b['bill_id'])?></span></td>
                            <td>
                                <div class="fw-600"><?=htmlspecialchars($b['patient_name'])?></div>
                                <div class="text-muted text-small"><?=htmlspecialchars($b['pid'])?></div>
                            </td>
                            <td><?=date('M d, Y',strtotime($b['bill_date']))?></td>
                            <td class="fw-600">&#8369;<?=number_format($b['total_amount'],2)?></td>
                            <td class="text-success fw-600">&#8369;<?=number_format($b['amount_paid'],2)?></td>
                            <td class="fw-600 <?=$b['balance']>0?'text-danger':'text-success'?>">&#8369;<?=number_format($b['balance'],2)?></td>
                            <td>
                                <?php if (($b['total_sukli'] ?? 0) > 0): ?>
                                <span class="badge" style="background:#ecfdf5;color:#047857;border:1px solid #10b981;font-weight:700;"><i class="fas fa-coins"></i> &#8369;<?=number_format($b['total_sukli'],2)?></span>
                                <?php else: ?>
                                <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="badge badge-<?=$status_colors[$b['payment_status']]?>"><?=$b['payment_status']?></span></td>
                            <td class="actions-cell">
                                <a href="?action=view&id=<?=$b['id']?>&tab=bills" class="btn btn-sm btn-outline" title="View Bill & Details"><i class="fas fa-eye"></i></a>
                                <?php if (!$is_patient && $b['balance'] > 0): ?>
                                <button type="button" class="btn btn-sm btn-success" title="Record Payment with Sukli Calculation" onclick="openPayModal(<?=$b['id']?>, '<?=htmlspecialchars(addslashes($b['bill_id']))?>', '<?=htmlspecialchars(addslashes($b['patient_name']))?>', <?=$b['balance']?>)">
                                    <i class="fas fa-money-bill-wave"></i> Pay
                                </button>
                                <?php endif; ?>
                                <?php if (!$is_patient): ?>
                                <a href="?action=delete&id=<?=$b['id']?>&tab=bills" class="btn btn-sm btn-danger" title="Delete Bill"
                                   onclick="return confirm('Delete bill <?=htmlspecialchars(addslashes($b['bill_id']))?>?')">
                                   <i class="fas fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($total_pages_b>1): ?>
                <div style="padding:16px 24px;"><div class="pagination">
                    <?php for ($i=1;$i<=$total_pages_b;$i++): ?>
                    <a href="?tab=bills&page=<?=$i?>&search=<?=urlencode($search)?>&status=<?=urlencode($filter_status)?>" class="page-link <?=$i===$page_num?'active':''?>"><?=$i?></a>
                    <?php endfor; ?>
                </div></div>
                <?php endif; ?>
            </div>

            <?php else: ?>
            <!-- PAYMENTS SECTION -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-money-bill-wave"></i> Recorded Payment Transactions</h3>
                    <?php if (!$is_patient): ?>
                    <button class="btn btn-success" onclick="openModal('recordPayModal')">
                        <i class="fas fa-plus"></i> Record New Payment
                    </button>
                    <?php endif; ?>
                </div>
                <div class="card-body" style="padding-bottom:0;">
                    <form method="GET" class="filter-bar">
                        <input type="hidden" name="tab" value="payments">
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" name="search" placeholder="Search payment ID, patient, bill ref..." value="<?=htmlspecialchars($search)?>">
                        </div>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                        <a href="/hmsystem/billing/index.php?tab=payments" class="btn btn-secondary"><i class="fas fa-times"></i> Clear</a>
                    </form>
                </div>
                <div class="table-wrapper">
                    <table>
                        <thead><tr>
                            <th>Payment ID</th><th>Bill Ref</th><th>Patient</th><th>Date</th>
                            <th>Amount Paid</th><th>Cash Tendered</th><th>Sukli (Change)</th><th>Method</th><th>Received By</th>
                        </tr></thead>
                        <tbody>
                        <?php if ($payments->num_rows===0): ?>
                        <tr><td colspan="9"><div class="empty-state"><i class="fas fa-receipt"></i><h4>No payment transactions found</h4></div></td></tr>
                        <?php else: while ($py=$payments->fetch_assoc()): ?>
                        <tr>
                            <td><span class="fw-600 text-primary"><?=htmlspecialchars($py['payment_id'])?></span></td>
                            <td><a href="?action=view&id=<?=$py['bill_id']?>&tab=bills" class="text-primary fw-600"><?=htmlspecialchars($py['bill_ref'])?></a></td>
                            <td>
                                <div class="fw-600"><?=htmlspecialchars($py['patient_name'])?></div>
                                <div class="text-muted text-small"><?=htmlspecialchars($py['pid'])?></div>
                            </td>
                            <td><?=date('M d, Y',strtotime($py['payment_date']))?></td>
                            <td class="fw-600 text-success">&#8369;<?=number_format($py['amount_paid'],2)?></td>
                            <td>&#8369;<?=number_format($py['cash_tendered'] ?: $py['amount_paid'],2)?></td>
                            <td>
                                <?php if (($py['change_amount'] ?? 0) > 0): ?>
                                <span class="badge badge-success">&#8369;<?=number_format($py['change_amount'],2)?></span>
                                <?php else: ?>
                                <span class="text-muted">&#8369;0.00</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <i class="fas <?= $py['payment_method']==='Cash'?'fa-money-bill':($py['payment_method']==='GCash'?'fa-mobile-alt':'fa-credit-card') ?> text-primary" style="margin-right:4px;"></i>
                                <?=htmlspecialchars($py['payment_method'])?>
                            </td>
                            <td><?=htmlspecialchars($py['received_by_name']??'Staff')?></td>
                        </tr>
                        <?php endwhile; endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($total_pages_p>1): ?>
                <div style="padding:16px 24px;"><div class="pagination">
                    <?php for ($i=1;$i<=$total_pages_p;$i++): ?>
                    <a href="?tab=payments&page=<?=$i?>&search=<?=urlencode($search)?>" class="page-link <?=$i===$page_num?'active':''?>"><?=$i?></a>
                    <?php endfor; ?>
                </div></div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div>
    </main>
</div>

<!-- ADD BILL MODAL (WITH AUTOMATIC PRICING & SERVICE CATALOGUE) -->
<div class="modal-overlay <?=$is_autobill?'active':''?>" id="addModal">
    <div class="modal modal-xl">
        <div class="modal-header">
            <h4><i class="fas fa-file-invoice"></i> Create Patient Bill</h4>
            <button class="modal-close" onclick="closeModal('addModal')"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
        <input type="hidden" name="form_action" value="add">
        <div class="modal-body">
            <div style="background:var(--bg-cream-box);border:1px solid var(--border-color);border-radius:var(--radius-sm);padding:14px 18px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
                <div>
                    <strong style="color:var(--navy-dark);font-size:14px;"><i class="fas fa-bolt text-warning"></i> Automatic Pricing Enabled</strong>
                    <div style="font-size:12.5px;color:var(--text-muted);">Choose standard services from the dropdown to auto-fill description and price.</div>
                </div>
                <button type="button" class="btn btn-sm btn-outline" onclick="addPresetRow('General Medical Consultation', 'Consultation', 500.00)">
                    <i class="fas fa-plus-circle"></i> + Add Consultation (₱500.00)
                </button>
            </div>

            <div class="form-grid form-grid-2">
                <div class="form-group">
                    <label class="form-label">Patient <span class="text-danger">*</span></label>
                    <select name="patient_id" class="form-control" required style="width: 100%;">
                        <option value="">Select Patient</option>
                        <?php foreach ($pt_list as $id => $name): ?>
                        <option value="<?=$id?>" <?=$prefill_patient_id==$id?'selected':''?>><?=htmlspecialchars($name)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Bill Date <span class="text-danger">*</span></label>
                    <input type="date" name="bill_date" class="form-control" required value="<?=date('Y-m-d')?>">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Notes / Attending Physician</label>
                <input type="text" name="notes" class="form-control" placeholder="e.g. Attending: Dr. Maria Garcia" value="<?=$prefill_doctor ? 'Attending: ' . htmlspecialchars($prefill_doctor) : ''?>">
            </div>

            <div style="margin-top:16px;">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                    <h5 style="font-size:14px;font-weight:700;color:var(--navy-dark);"><i class="fas fa-list text-primary"></i> Bill Items & Automatic Pricing</h5>
                    <button type="button" class="btn btn-sm btn-outline" onclick="addBillRow()"><i class="fas fa-plus"></i> Add Custom Item</button>
                </div>
                <div style="overflow-x:auto;">
                <table style="width:100%;border-collapse:collapse;" id="billItemsTable">
                    <thead><tr style="background:var(--bg-cream-box);">
                        <th style="padding:10px 12px;font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;width:240px;">Select Standard Service</th>
                        <th style="padding:10px 12px;font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;">Item Description</th>
                        <th style="padding:10px 12px;font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;width:130px;">Type</th>
                        <th style="padding:10px 12px;font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;width:70px;">Qty</th>
                        <th style="padding:10px 12px;font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;width:120px;">Price (₱)</th>
                        <th style="padding:10px 12px;font-size:12px;font-weight:700;color:var(--text-muted);text-transform:uppercase;width:120px;">Subtotal</th>
                        <th style="padding:10px 12px;width:40px;"></th>
                    </tr></thead>
                    <tbody id="billItemsBody">
                        <tr class="bill-row">
                            <td style="padding:6px 8px;">
                                <select class="form-control service-preset" onchange="onSelectServicePreset(this)">
                                    <option value="">-- Choose Standard Service --</option>
                                    <?php foreach ($service_catalogue as $sc): ?>
                                    <option value="<?=htmlspecialchars($sc['name'])?>" data-type="<?=$sc['type']?>" data-price="<?=$sc['price']?>"><?=htmlspecialchars($sc['name'])?> (₱<?=number_format($sc['price'],2)?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td style="padding:6px 8px;"><input type="text" name="desc[]" class="form-control desc-inp" placeholder="e.g. General Consultation" required value="<?=$is_autobill?'General Medical Consultation':''?>"></td>
                            <td style="padding:6px 8px;"><select name="service_type[]" class="form-control type-inp">
                                <?php foreach (['Consultation','Laboratory','Radiology','Procedure','Medicine','Vaccination','Dental','Accommodation','Service','Other'] as $st): ?>
                                <option <?=$is_autobill&&$st==='Consultation'?'selected':''?>><?=$st?></option><?php endforeach; ?>
                            </select></td>
                            <td style="padding:6px 8px;"><input type="number" name="qty[]" class="form-control qty-inp" value="1" min="1" oninput="calcRow(this)"></td>
                            <td style="padding:6px 8px;"><input type="number" name="price[]" class="form-control price-inp" value="<?=$is_autobill?'500.00':'0'?>" step="0.01" min="0" oninput="calcRow(this)"></td>
                            <td style="padding:6px 8px;"><input type="text" class="form-control subtotal-inp" readonly value="<?=$is_autobill?'500.00':'0.00'?>" style="background:#f8f9fa;"></td>
                            <td style="padding:6px 8px;"><button type="button" class="btn btn-sm btn-danger btn-icon" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>
                        </tr>
                    </tbody>
                </table>
                </div>
                <div style="margin-top:14px;text-align:right;">
                    <div style="display:inline-block;background:var(--primary-light);padding:12px 24px;border-radius:10px;">
                        <span style="font-size:13px;color:var(--text-muted);">Total Bill Amount: </span>
                        <span id="grandTotal" style="font-size:22px;font-weight:800;color:var(--primary);">₱<?=$is_autobill?'500.00':'0.00'?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Cancel</button>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save & Generate Bill</button>
        </div>
        </form>
    </div>
</div>

<!-- RECORD PAYMENT MODAL (WITH LIVE SUKLI / CHANGE DISPLAY) -->
<div class="modal-overlay" id="recordPayModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h4><i class="fas fa-cash-register text-success"></i> Record Payment & Sukli Calculation</h4>
            <button class="modal-close" onclick="closeModal('recordPayModal')"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
        <input type="hidden" name="form_action" value="pay">
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Bill Reference <span class="text-danger">*</span></label>
                <select name="bill_id" class="form-control" required id="payBillSelect" onchange="onSelectPayBill(this)" style="width: 100%;">
                    <option value="">-- Select Unpaid / Partially Paid Bill --</option>
                    <?php foreach ($unpaid_bills as $bid => $ub): ?>
                    <option value="<?=$bid?>" data-balance="<?=$ub['balance']?>" data-total="<?=$ub['total_amount']?>" data-patient="<?=htmlspecialchars($ub['pname'])?>">
                        <?=$ub['bill_id']?> — <?=htmlspecialchars($ub['pname'])?> (Balance: ₱<?=number_format($ub['balance'],2)?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div id="selectedBillBanner" style="display:none;background:var(--bg-cream-box);border:1px solid var(--border-color);border-radius:8px;padding:12px 16px;margin-bottom:16px;">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <div>
                        <div style="font-size:12px;color:var(--text-muted);text-transform:uppercase;font-weight:600;">Patient</div>
                        <div id="bannerPatientName" style="font-size:15px;font-weight:700;color:var(--navy-dark);"></div>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:12px;color:var(--text-muted);text-transform:uppercase;font-weight:600;">Remaining Balance</div>
                        <div id="bannerBalanceAmount" style="font-size:18px;font-weight:800;color:var(--primary);">₱0.00</div>
                    </div>
                </div>
            </div>

            <div class="form-grid form-grid-2">
                <div class="form-group">
                    <label class="form-label">Payment Date <span class="text-danger">*</span></label>
                    <input type="date" name="payment_date" class="form-control" required value="<?=date('Y-m-d')?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Amount to Pay / Credit (₱) <span class="text-danger">*</span></label>
                    <input type="number" id="payAmountInput" name="amount_paid" class="form-control" required step="0.01" min="0.01" value="" oninput="calculateSukli()">
                </div>
            </div>

            <div class="form-grid form-grid-2">
                <div class="form-group">
                    <label class="form-label">Payment Method <span class="text-danger">*</span></label>
                    <select name="payment_method" id="payMethodSelect" class="form-control" required onchange="toggleCashFields()">
                        <option value="Cash">Cash</option>
                        <option value="GCash">GCash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Reference / Transaction Number</label>
                    <input type="text" name="reference_number" class="form-control" placeholder="e.g. GCash Ref / Bank Txn #">
                </div>
            </div>

            <!-- CASH TENDERED & SUKLI BOX -->
            <div id="cashTenderSection">
                <div class="form-group" style="margin-top:8px;">
                    <label class="form-label">Cash Received / Halaga ng Binayad (₱) <span class="text-danger">*</span></label>
                    <input type="number" id="cashTenderInput" name="cash_tendered" class="form-control" step="0.01" min="0" placeholder="Enter amount handed by patient" oninput="calculateSukli()">
                    <div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">
                        <span style="font-size:12px;color:var(--text-muted);display:flex;align-items:center;">Quick buttons:</span>
                        <button type="button" class="quick-cash-btn" onclick="setExactTender()">Exact Amount</button>
                        <button type="button" class="quick-cash-btn" onclick="setCashTender(500)">₱500</button>
                        <button type="button" class="quick-cash-btn" onclick="setCashTender(1000)">₱1,000</button>
                        <button type="button" class="quick-cash-btn" onclick="setCashTender(2000)">₱2,000</button>
                        <button type="button" class="quick-cash-btn" onclick="setCashTender(5000)">₱5,000</button>
                    </div>
                </div>

                <div class="sukli-card" id="sukliCard">
                    <div>
                        <div class="sukli-label"><i class="fas fa-hand-holding-dollar"></i> Sukli (Change to Return)</div>
                        <small style="color:#065f46;font-size:12px;">Automatic live calculation based on cash received</small>
                    </div>
                    <div class="sukli-value" id="sukliDisplay">₱0.00</div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Notes</label>
                <input type="text" name="notes" class="form-control" placeholder="Optional notes...">
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('recordPayModal')">Cancel</button>
            <button type="submit" class="btn btn-success"><i class="fas fa-check-circle"></i> Confirm & Record Payment</button>
        </div>
        </form>
    </div>
</div>

<!-- VIEW BILL MODAL -->
<?php if ($view_bill && $action==='view'): ?>
<div class="modal-overlay active" id="viewModal">
    <div class="modal modal-xl">
        <div class="modal-header">
            <h4><i class="fas fa-file-invoice-dollar"></i> Bill Statement — <?=htmlspecialchars($view_bill['bill_id'])?></h4>
            <a href="/hmsystem/billing/index.php?tab=<?=$tab?>" class="modal-close"><i class="fas fa-times"></i></a>
        </div>
        <div class="modal-body" id="printableBillArea">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-bottom:20px;">
                <div>
                    <div class="info-item" style="margin-bottom:10px;"><div class="label">Bill ID</div><div class="value text-primary fw-600"><?=htmlspecialchars($view_bill['bill_id'])?></div></div>
                    <div class="info-item" style="margin-bottom:10px;"><div class="label">Patient</div><div class="value"><?=htmlspecialchars($view_bill['patient_name'])?> (<?=htmlspecialchars($view_bill['pid'])?>)</div></div>
                    <div class="info-item" style="margin-bottom:10px;"><div class="label">Bill Date</div><div class="value"><?=date('F d, Y',strtotime($view_bill['bill_date']))?></div></div>
                    <?php if ($view_bill['notes']): ?><div class="info-item"><div class="label">Notes</div><div class="value"><?=htmlspecialchars($view_bill['notes'])?></div></div><?php endif; ?>
                </div>
                <div style="background:var(--bg-cream-box);border:1px solid var(--border-color);border-radius:12px;padding:20px;">
                    <div style="margin-bottom:10px;display:flex;justify-content:space-between;"><span style="color:var(--text-muted);">Total Amount:</span><span class="fw-700 text-dark">&#8369;<?=number_format($view_bill['total_amount'],2)?></span></div>
                    <div style="margin-bottom:10px;display:flex;justify-content:space-between;"><span style="color:var(--text-muted);">Amount Paid:</span><span class="fw-700 text-success">&#8369;<?=number_format($view_bill['amount_paid'],2)?></span></div>
                    <div style="margin-bottom:12px;display:flex;justify-content:space-between;"><span style="color:var(--text-muted);">Remaining Balance:</span><span class="fw-700 <?=$view_bill['balance']>0?'text-danger':'text-success'?>">&#8369;<?=number_format($view_bill['balance'],2)?></span></div>
                    <?php if (($view_bill['total_sukli'] ?? 0) > 0): ?>
                    <div style="margin-bottom:14px;display:flex;justify-content:space-between;align-items:center;background:#ecfdf5;border:1px dashed #059669;padding:10px 14px;border-radius:8px;">
                        <span style="font-weight:700;color:#047857;font-size:13px;"><i class="fas fa-hand-holding-dollar"></i> Sukli (Change):</span>
                        <span class="fw-800" style="color:#059669;font-size:18px;">&#8369;<?=number_format($view_bill['total_sukli'],2)?></span>
                    </div>
                    <?php endif; ?>
                    <div style="text-align:center;">
                        <span class="badge badge-<?=$status_colors[$view_bill['payment_status']]?>" style="font-size:13px;padding:6px 16px;"><?=$view_bill['payment_status']?></span>
                    </div>
                </div>
            </div>

            <!-- Bill Items -->
            <h5 style="font-weight:700;font-size:14px;margin-bottom:10px;color:var(--navy-dark);"><i class="fas fa-list text-primary"></i> Bill Items Breakdown</h5>
            <div class="table-wrapper" style="margin-bottom:20px;">
                <table>
                    <thead><tr><th>Description</th><th>Service Type</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr></thead>
                    <tbody>
                    <?php foreach ($bill_items_list as $item): ?>
                    <tr>
                        <td><?=htmlspecialchars($item['description'])?></td>
                        <td><?=htmlspecialchars($item['service_type']??'')?></td>
                        <td><?=htmlspecialchars($item['quantity'])?></td>
                        <td>&#8369;<?=number_format($item['unit_price'],2)?></td>
                        <td class="fw-600">&#8369;<?=number_format($item['subtotal'],2)?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr style="background:var(--bg-cream-box);">
                        <td colspan="4" style="text-align:right;font-weight:700;">TOTAL</td>
                        <td class="fw-600 text-primary">&#8369;<?=number_format($view_bill['total_amount'],2)?></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <!-- Payment History with Sukli (Change) -->
            <?php if (!empty($bill_payments)): ?>
            <h5 style="font-weight:700;font-size:14px;margin-bottom:10px;color:var(--navy-dark);"><i class="fas fa-receipt text-success"></i> Payment History & Sukli Dispensed</h5>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Payment ID</th><th>Date</th><th>Amount Paid</th><th>Cash Received</th><th>Sukli (Change)</th><th>Method</th><th>Reference</th><th>Received By</th></tr></thead>
                    <tbody>
                    <?php foreach ($bill_payments as $py): ?>
                    <tr>
                        <td class="fw-600 text-primary"><?=htmlspecialchars($py['payment_id'])?></td>
                        <td><?=date('M d, Y',strtotime($py['payment_date']))?></td>
                        <td class="fw-600 text-success">&#8369;<?=number_format($py['amount_paid'],2)?></td>
                        <td>&#8369;<?=number_format($py['cash_tendered'] ?: $py['amount_paid'],2)?></td>
                        <td>
                            <?php if (($py['change_amount'] ?? 0) > 0): ?>
                            <span class="badge badge-success">&#8369;<?=number_format($py['change_amount'],2)?></span>
                            <?php else: ?>
                            <span class="text-muted">&#8369;0.00</span>
                            <?php endif; ?>
                        </td>
                        <td><?=htmlspecialchars($py['payment_method'])?></td>
                        <td><?=htmlspecialchars($py['reference_number']?:'—')?></td>
                        <td><?=htmlspecialchars($py['received_by_name']?:'—')?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
        <div class="modal-footer">
            <a href="/hmsystem/billing/index.php?tab=<?=$tab?>" class="btn btn-secondary">Close</a>
            <?php if (!$is_patient && $view_bill['balance'] > 0): ?>
            <button type="button" class="btn btn-success" onclick="openPayModal(<?=$view_bill['id']?>, '<?=htmlspecialchars(addslashes($view_bill['bill_id']))?>', '<?=htmlspecialchars(addslashes($view_bill['patient_name']))?>', <?=$view_bill['balance']?>)">
                <i class="fas fa-money-bill-wave"></i> Record Payment
            </button>
            <?php endif; ?>
            <button onclick="window.print()" class="btn btn-outline"><i class="fas fa-print"></i> Print Statement / Receipt</button>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
document.querySelectorAll('.modal-overlay').forEach(el=>{
    el.addEventListener('click',function(e){if(e.target===el)closeModal(el.id);});
});

const serviceTypes = ['Consultation','Laboratory','Radiology','Procedure','Medicine','Vaccination','Dental','Accommodation','Service','Other'];
const catalogue = <?=json_encode($service_catalogue)?>;

function openAutoBillModal(){
    openModal('addModal');
}

function onSelectServicePreset(sel){
    const row = sel.closest('tr');
    const opt = sel.options[sel.selectedIndex];
    if(opt && opt.value){
        row.querySelector('.desc-inp').value = opt.value;
        const type = opt.getAttribute('data-type');
        const price = opt.getAttribute('data-price');
        if(type) row.querySelector('.type-inp').value = type;
        if(price) row.querySelector('.price-inp').value = parseFloat(price).toFixed(2);
        calcRow(row.querySelector('.price-inp'));
    }
}

function addPresetRow(name, type, price){
    const tbody = document.getElementById('billItemsBody');
    const tr = document.createElement('tr');
    tr.className='bill-row';
    tr.innerHTML = `
        <td style="padding:6px 8px;">
            <select class="form-control service-preset" onchange="onSelectServicePreset(this)">
                <option value="">-- Choose Standard Service --</option>
                ${catalogue.map(c=>`<option value="${c.name}" data-type="${c.type}" data-price="${c.price}" ${c.name===name?'selected':''}>${c.name} (₱${c.price.toFixed(2)})</option>`).join('')}
            </select>
        </td>
        <td style="padding:6px 8px;"><input type="text" name="desc[]" class="form-control desc-inp" value="${name}" required></td>
        <td style="padding:6px 8px;"><select name="service_type[]" class="form-control type-inp">${serviceTypes.map(t=>`<option ${t===type?'selected':''}>${t}</option>`).join('')}</select></td>
        <td style="padding:6px 8px;"><input type="number" name="qty[]" class="form-control qty-inp" value="1" min="1" oninput="calcRow(this)"></td>
        <td style="padding:6px 8px;"><input type="number" name="price[]" class="form-control price-inp" value="${price.toFixed(2)}" step="0.01" min="0" oninput="calcRow(this)"></td>
        <td style="padding:6px 8px;"><input type="text" class="form-control subtotal-inp" readonly value="${price.toFixed(2)}" style="background:#f8f9fa;"></td>
        <td style="padding:6px 8px;"><button type="button" class="btn btn-sm btn-danger btn-icon" onclick="removeRow(this)"><i class="fas fa-times"></i></button></td>`;
    tbody.appendChild(tr);
    updateTotal();
}

function addBillRow(){
    addPresetRow('', 'Consultation', 0.00);
}

function removeRow(btn){
    const rows = document.querySelectorAll('.bill-row');
    if(rows.length > 1){ btn.closest('tr').remove(); updateTotal(); }
}

function calcRow(inp){
    const row = inp.closest('tr');
    const qty = parseFloat(row.querySelector('.qty-inp').value) || 0;
    const price = parseFloat(row.querySelector('.price-inp').value) || 0;
    const sub = qty * price;
    row.querySelector('.subtotal-inp').value = sub.toFixed(2);
    updateTotal();
}

function updateTotal(){
    let total = 0;
    document.querySelectorAll('.subtotal-inp').forEach(inp => { total += parseFloat(inp.value) || 0; });
    document.getElementById('grandTotal').textContent = '₱' + total.toLocaleString('en-PH',{minimumFractionDigits:2});
}

// SUKLI / CHANGE CALCULATION LOGIC
function openPayModal(billId, billRef, patientName, balance){
    const select = document.getElementById('payBillSelect');
    if(select) {
        select.value = billId;
        onSelectPayBill(select);
    }
    openModal('recordPayModal');
}

function onSelectPayBill(sel){
    const opt = sel.options[sel.selectedIndex];
    const banner = document.getElementById('selectedBillBanner');
    if(opt && opt.value){
        const bal = parseFloat(opt.getAttribute('data-balance')) || 0;
        const pt = opt.getAttribute('data-patient') || '';
        banner.style.display = 'block';
        document.getElementById('bannerPatientName').textContent = pt;
        document.getElementById('bannerBalanceAmount').textContent = '₱' + bal.toLocaleString('en-PH',{minimumFractionDigits:2});
        document.getElementById('payAmountInput').value = bal.toFixed(2);
        document.getElementById('cashTenderInput').value = bal.toFixed(2);
        calculateSukli();
    } else {
        banner.style.display = 'none';
        document.getElementById('payAmountInput').value = '';
        document.getElementById('cashTenderInput').value = '';
        calculateSukli();
    }
}

function calculateSukli(){
    const amount = parseFloat(document.getElementById('payAmountInput').value) || 0;
    const tender = parseFloat(document.getElementById('cashTenderInput').value) || 0;
    const sukli = Math.max(0, tender - amount);
    const sukliEl = document.getElementById('sukliDisplay');
    sukliEl.textContent = '₱' + sukli.toLocaleString('en-PH', {minimumFractionDigits: 2});
    if(tender < amount && tender > 0){
        sukliEl.style.color = '#dc2626';
        sukliEl.textContent = 'Insufficient (₱' + (amount - tender).toLocaleString('en-PH',{minimumFractionDigits:2}) + ' lacking)';
    } else {
        sukliEl.style.color = '#059669';
    }
}

function setExactTender(){
    const amount = parseFloat(document.getElementById('payAmountInput').value) || 0;
    document.getElementById('cashTenderInput').value = amount.toFixed(2);
    calculateSukli();
}

function setCashTender(val){
    document.getElementById('cashTenderInput').value = val.toFixed(2);
    calculateSukli();
}

function toggleCashFields(){
    const method = document.getElementById('payMethodSelect').value;
    const cashSec = document.getElementById('cashTenderSection');
    if(method === 'Cash'){
        cashSec.style.display = 'block';
    } else {
        cashSec.style.display = 'none';
    }
}
</script>
</body>
</html>
<?php $conn->close(); ?>
