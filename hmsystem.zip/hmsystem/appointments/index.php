<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth_functions.php';
requireLogin();

$conn = getDBConnection();
$page_title = 'Appointments';
$page_subtitle = 'Manage patient appointments';
$page_active = 'appointments';

$message = '';
$error = '';

$action = $_GET['action'] ?? '';
$appt_id = intval($_GET['id'] ?? 0);

if (isset($_SESSION['flash_message'])) {
    $message = $_SESSION['flash_message'];
    unset($_SESSION['flash_message']);
}

// Fetch departments for dropdown (Emergency removed)
$depts = $conn->query("SELECT id, name FROM departments WHERE status='active' AND LOWER(name) != 'emergency' ORDER BY name");
$dept_list = [];
while ($d = $depts->fetch_assoc()) $dept_list[$d['id']] = $d['name'];

// Predefined non-editable hospital schedule slots
$schedule_slots = [
    '08:00:00' => '08:00 AM',
    '08:30:00' => '08:30 AM',
    '09:00:00' => '09:00 AM',
    '09:30:00' => '09:30 AM',
    '10:00:00' => '10:00 AM',
    '10:30:00' => '10:30 AM',
    '11:00:00' => '11:00 AM',
    '11:30:00' => '11:30 AM',
    '13:00:00' => '01:00 PM',
    '13:30:00' => '01:30 PM',
    '14:00:00' => '02:00 PM',
    '14:30:00' => '02:30 PM',
    '15:00:00' => '03:00 PM',
    '15:30:00' => '03:30 PM',
    '16:00:00' => '04:00 PM',
    '16:30:00' => '04:30 PM',
    '17:00:00' => '05:00 PM',
];

// Fetch booked slots to prevent taking same date and same time
$booked_q = $conn->query("SELECT id, doctor_name, appointment_date, appointment_time FROM appointments WHERE status != 'Cancelled'");
$booked_slots = [];
while ($br = $booked_q->fetch_assoc()) {
    $key = trim($br['doctor_name']) . '|' . $br['appointment_date'];
    if (!isset($booked_slots[$key])) $booked_slots[$key] = [];
    $booked_slots[$key][] = [
        'id' => intval($br['id']),
        'time' => substr($br['appointment_time'], 0, 5),
        'time_full' => $br['appointment_time']
    ];
}

// Fetch patients for dropdown
$pts = $conn->query("SELECT id, patient_id, CONCAT(first_name,' ',last_name) as full_name FROM patients WHERE status='Active' ORDER BY first_name");
$pt_list = [];
while ($p = $pts->fetch_assoc()) $pt_list[$p['id']] = $p['patient_id'] . ' - ' . $p['full_name'];

// Fetch doctors for dropdown
$doctors_list = [
    'Dr. Maria Garcia',
    'Dr. Jose Reyes',
    'Dr. Carl Bautista',
    'Dr. Lisa Navarro',
    'Dr. Ana Lim',
    'Dr. Mark Torres',
    'Dr. Juan Santos',
];
$doc_appts = $conn->query("SELECT DISTINCT doctor_name FROM appointments WHERE doctor_name IS NOT NULL AND doctor_name != ''");
if ($doc_appts) {
    while ($da = $doc_appts->fetch_assoc()) {
        if (!in_array($da['doctor_name'], $doctors_list)) {
            $doctors_list[] = $da['doctor_name'];
        }
    }
}
sort($doctors_list);

$is_patient = isPatient();
$my_patient_id = getPatientId();
if ($is_patient && (!$my_patient_id || $my_patient_id == 0) && !empty($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $u_stmt = $conn->prepare("SELECT patient_id, email, full_name FROM users WHERE id = ? LIMIT 1");
    $u_stmt->bind_param("i", $user_id);
    $u_stmt->execute();
    if ($u_row = $u_stmt->get_result()->fetch_assoc()) {
        if (!empty($u_row['patient_id'])) {
            $my_patient_id = $u_row['patient_id'];
        } else {
            $email = $u_row['email'];
            $p_stmt = $conn->prepare("SELECT id FROM patients WHERE email = ? LIMIT 1");
            $p_stmt->bind_param("s", $email);
            $p_stmt->execute();
            if ($p_res = $p_stmt->get_result()->fetch_assoc()) {
                $my_patient_id = $p_res['id'];
            } else {
                $new_pt_str = generateID('PT', 'patients', 'patient_id', $conn);
                $names = explode(' ', $u_row['full_name'], 2);
                $fname = $names[0] ?? 'Patient';
                $lname = $names[1] ?? 'User';
                $reg_date = date('Y-m-d');
                $ins_p = $conn->prepare("INSERT INTO patients (patient_id, first_name, last_name, email, status, registration_date) VALUES (?, ?, ?, ?, 'Active', ?)");
                $ins_p->bind_param("sssss", $new_pt_str, $fname, $lname, $email, $reg_date);
                $ins_p->execute();
                $my_patient_id = $conn->insert_id;
                $ins_p->close();
            }
            $p_stmt->close();
            $conn->query("UPDATE users SET patient_id = $my_patient_id WHERE id = $user_id");
        }
        $_SESSION['patient_id'] = $my_patient_id;
    }
    $u_stmt->close();
}

// APPROVE appointment
if (in_array($action, ['approve', 'accept']) && $appt_id && !$is_patient) {
    $stmt = $conn->prepare("UPDATE appointments SET status='Scheduled' WHERE id=?");
    $stmt->bind_param("i", $appt_id);
    if ($stmt->execute()) {
        logActivity($conn, $_SESSION['user_id'], 'Appointment Approved', "Approved appointment ID: $appt_id");
        $_SESSION['flash_message'] = "Appointment ID #$appt_id has been approved and scheduled successfully.";
        header("Location: /hmsystem/appointments/index.php");
        exit();
    }
    $stmt->close();
}

// DECLINE appointment
if (in_array($action, ['decline', 'cancel']) && $appt_id && !$is_patient) {
    $stmt = $conn->prepare("UPDATE appointments SET status='Cancelled' WHERE id=?");
    $stmt->bind_param("i", $appt_id);
    if ($stmt->execute()) {
        logActivity($conn, $_SESSION['user_id'], 'Appointment Declined', "Declined appointment ID: $appt_id");
        $_SESSION['flash_message'] = "Appointment ID #$appt_id has been declined.";
        header("Location: /hmsystem/appointments/index.php");
        exit();
    }
    $stmt->close();
}

// DELETE
if ($action === 'delete' && $appt_id && !$is_patient) {
    $stmt = $conn->prepare("DELETE FROM appointments WHERE id=?");
    $stmt->bind_param("i", $appt_id);
    $stmt->execute();
    $stmt->close();
    logActivity($conn, $_SESSION['user_id'], 'Appointment Deleted', "Deleted appointment ID: $appt_id");
    $_SESSION['flash_message'] = 'Appointment deleted successfully.';
    header("Location: /hmsystem/appointments/index.php");
    exit();
}

// ADD
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_action']??'') === 'add') {
    $new_id = generateID('APT', 'appointments', 'appointment_id', $conn);
    $pid = $is_patient ? (intval($my_patient_id) ?: intval($_POST['patient_id'] ?? 0)) : intval($_POST['patient_id'] ?? 0);

    // Extra safety: if patient user, always guarantee patient_id exists
    if ($is_patient && (!$pid || $pid == 0)) {
        $uid_check = intval($_SESSION['user_id'] ?? 0);
        $u_row = $conn->query("SELECT patient_id, email, full_name FROM users WHERE id = $uid_check")->fetch_assoc();
        if (!empty($u_row['patient_id'])) {
            $pid = intval($u_row['patient_id']);
        } else {
            $em_safe = $conn->real_escape_string($u_row['email'] ?? '');
            $pt_check = $conn->query("SELECT id FROM patients WHERE email = '$em_safe' LIMIT 1")->fetch_assoc();
            if ($pt_check) {
                $pid = intval($pt_check['id']);
            } else {
                $new_pt = generateID('PT', 'patients', 'patient_id', $conn);
                $names = explode(' ', $u_row['full_name'] ?? 'Patient User', 2);
                $fname = $names[0] ?? 'Patient';
                $lname = $names[1] ?? 'User';
                $today = date('Y-m-d');
                $conn->query("INSERT INTO patients (patient_id, first_name, last_name, email, status, registration_date) VALUES ('$new_pt', '" . $conn->real_escape_string($fname) . "', '" . $conn->real_escape_string($lname) . "', '$em_safe', 'Active', '$today')");
                $pid = $conn->insert_id;
            }
            $conn->query("UPDATE users SET patient_id = $pid WHERE id = $uid_check");
        }
        $my_patient_id = $pid;
        $_SESSION['patient_id'] = $pid;
    }

    $did = intval($_POST['department_id'] ?? 0);
    $doc = trim($_POST['doctor_name'] ?? '');
    $date = trim($_POST['appointment_date'] ?? '');
    $time = trim($_POST['appointment_time'] ?? '');
    $purpose = trim($_POST['purpose'] ?? '');
    $status = $is_patient ? 'Pending' : ($_POST['status'] ?? 'Pending');
    $notes = trim($_POST['notes'] ?? '');

    if ($date && $date < date('Y-m-d')) {
        $error = 'Previous dates are already past and cannot be booked. Please select today or a future date.';
    } elseif (!$pid || !$did || !$date || !$time) {
        $missing = [];
        if (!$pid) $missing[] = 'Patient Profile';
        if (!$did) $missing[] = 'Department';
        if (!$date) $missing[] = 'Appointment Date';
        if (!$time) $missing[] = 'Appointment Time';
        $error = 'Please fill in all required fields (' . implode(', ', $missing) . ').';
    } else {
        // Prevent duplicate appointment on same date & same time for the doctor
        $chk = $conn->prepare("SELECT id FROM appointments WHERE doctor_name = ? AND appointment_date = ? AND appointment_time = ? AND status != 'Cancelled'");
        $chk->bind_param("sss", $doc, $date, $time);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $error = "The doctor ($doc) is already booked on " . date('M d, Y', strtotime($date)) . " at " . date('h:i A', strtotime($time)) . ". Bawal na pong kunin ang slot na ito. Please choose another time slot.";
            $chk->close();
        } else {
            $chk->close();
            $uid = intval($_SESSION['user_id'] ?? 0);
            $stmt = $conn->prepare("INSERT INTO appointments (appointment_id,patient_id,department_id,doctor_name,appointment_date,appointment_time,purpose,status,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("siissssssi",$new_id,$pid,$did,$doc,$date,$time,$purpose,$status,$notes,$uid);
            if ($stmt->execute()) {
                $pname = $pt_list[$pid] ?? "Patient #$pid";
                logActivity($conn, $uid, 'Appointment Created', "Created appointment $new_id for $pname");
                $_SESSION['flash_message'] = "Appointment $new_id requested successfully!";
                header("Location: /hmsystem/appointments/index.php");
                exit();
            } else {
                $error = 'Error creating appointment: ' . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// EDIT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_action']??'') === 'edit' && !$is_patient) {
    $eid = intval($_POST['edit_id']);
    $pid = intval($_POST['patient_id']);
    $did = intval($_POST['department_id']);
    $doc = trim($_POST['doctor_name']);
    $date = $_POST['appointment_date'];
    $time = $_POST['appointment_time'];
    $purpose = trim($_POST['purpose']);
    $status = $_POST['status'];
    $notes = trim($_POST['notes']);

    if ($date && $date < date('Y-m-d')) {
        $error = 'Previous dates are already past and cannot be booked. Please select today or a future date.';
    } else {
        // Prevent duplicate appointment on same date & same time for the doctor
        $chk = $conn->prepare("SELECT id FROM appointments WHERE doctor_name = ? AND appointment_date = ? AND appointment_time = ? AND status != 'Cancelled' AND id != ?");
        $chk->bind_param("sssi", $doc, $date, $time, $eid);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $error = "The doctor ($doc) is already booked on " . date('M d, Y', strtotime($date)) . " at " . date('h:i A', strtotime($time)) . ". Bawal na pong kunin ang slot na ito. Please choose another time slot.";
            $chk->close();
        } else {
            $chk->close();
            $stmt = $conn->prepare("UPDATE appointments SET patient_id=?,department_id=?,doctor_name=?,appointment_date=?,appointment_time=?,purpose=?,status=?,notes=? WHERE id=?");
            $stmt->bind_param("iissssssi",$pid,$did,$doc,$date,$time,$purpose,$status,$notes,$eid);
            if ($stmt->execute()) {
                logActivity($conn, $_SESSION['user_id'], 'Appointment Updated', "Updated appointment ID: $eid");
                $_SESSION['flash_message'] = 'Appointment updated successfully.';
                header("Location: /hmsystem/appointments/index.php");
                exit();
            } else {
                $error = 'Error updating appointment.';
            }
            $stmt->close();
        }
    }
}

// Search/filter
$search = trim($_GET['search'] ?? '');
$filter_status = $_GET['status'] ?? '';
$filter_dept = intval($_GET['dept'] ?? 0);
$filter_date = $_GET['date'] ?? '';
$filter_pid = intval($_GET['patient_id'] ?? 0);

$where = "WHERE 1=1";
$params = []; $types = '';

if ($is_patient) {
    $where .= " AND a.patient_id=?";
    $params[] = $my_patient_id ? $my_patient_id : 0;
    $types .= 'i';
} elseif ($filter_pid) {
    $where .= " AND a.patient_id=?";
    $params[] = $filter_pid;
    $types .= 'i';
}
if ($search) {
    $s = "%$search%";
    $where .= " AND (a.appointment_id LIKE ? OR CONCAT(p.first_name,' ',p.last_name) LIKE ? OR a.doctor_name LIKE ?)";
    $params = array_merge($params, [$s,$s,$s]); $types .= 'sss';
}
if ($filter_status) { $where .= " AND a.status=?"; $params[] = $filter_status; $types .= 's'; }
if ($filter_dept) { $where .= " AND a.department_id=?"; $params[] = $filter_dept; $types .= 'i'; }
if ($filter_date) { $where .= " AND a.appointment_date=?"; $params[] = $filter_date; $types .= 's'; }

$per_page = 12; $page_num = max(1, intval($_GET['page'] ?? 1)); $offset = ($page_num-1)*$per_page;

$count_q = $conn->prepare("SELECT COUNT(*) as cnt FROM appointments a JOIN patients p ON a.patient_id=p.id $where");
if ($types) $count_q->bind_param($types, ...$params);
$count_q->execute();
$total_rows = $count_q->get_result()->fetch_assoc()['cnt'];
$total_pages = ceil($total_rows/$per_page);
$count_q->close();

$all_params = $params; $all_params[] = $per_page; $all_params[] = $offset;
$all_types = $types . 'ii';
$stmt = $conn->prepare("SELECT a.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_id as pid, d.name as dept_name FROM appointments a JOIN patients p ON a.patient_id=p.id JOIN departments d ON a.department_id=d.id $where ORDER BY a.appointment_date DESC, a.appointment_time DESC LIMIT ? OFFSET ?");
$stmt->bind_param($all_types, ...$all_params);
$stmt->execute();
$appointments = $stmt->get_result();
$stmt->close();

// Fetch for view/edit
$view_appt = null;
if (in_array($action,['view','edit']) && $appt_id) {
    $s = $conn->prepare("SELECT a.*, CONCAT(p.first_name,' ',p.last_name) as patient_name, p.patient_id as pid FROM appointments a JOIN patients p ON a.patient_id=p.id WHERE a.id=?");
    $s->bind_param("i",$appt_id);
    $s->execute();
    $view_appt = $s->get_result()->fetch_assoc();
    $s->close();
}

$status_colors = ['Scheduled'=>'info','Completed'=>'success','Cancelled'=>'danger','Pending'=>'warning'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - Gerona Hospital </title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="/hmsystem/assets/css/style.css?v=<?= filemtime(__DIR__ . '/../assets/css/style.css') ?>">
</head>
<body>
<div class="layout">
    <?php include __DIR__ . '/../includes/sidebar.php'; ?>
    <main class="main-content">
        <?php include __DIR__ . '/../includes/header.php'; ?>
        <div class="page-body">

            <?php if ($message): ?><div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($message) ?></div><?php endif; ?>
            <?php if ($error): ?><div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?></div><?php endif; ?>

            <?php if ($filter_pid): ?>
            <div class="alert alert-info"><i class="fas fa-info-circle"></i>
                Showing appointments for: <?= htmlspecialchars($pt_list[$filter_pid] ?? "Patient #$filter_pid") ?>
                <a href="/hmsystem/appointments/index.php" style="margin-left:12px;" class="btn btn-sm btn-secondary">Show All</a>
            </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-check"></i> Appointments (<?= number_format($total_rows) ?>)</h3>
                    <button class="btn btn-primary" onclick="openModal('addModal')"><i class="fas fa-plus"></i> New Appointment</button>
                </div>
                <div class="card-body" style="padding-bottom:0;">
                    <form method="GET" class="filter-bar">
                        <?php if ($filter_pid): ?><input type="hidden" name="patient_id" value="<?= $filter_pid ?>"><?php endif; ?>
                        <div class="search-box">
                            <i class="fas fa-search"></i>
                            <input type="text" name="search" placeholder="Search appointments..." value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <input type="date" name="date" class="form-control" style="width:160px;" value="<?= htmlspecialchars($filter_date) ?>" onchange="this.form.submit()">
                        <select name="status" class="form-control" style="width:140px;" onchange="this.form.submit()">
                            <option value="">All Status</option>
                            <?php foreach (['Pending','Scheduled','Completed','Cancelled'] as $s): ?>
                            <option value="<?= $s ?>" <?= $filter_status===$s?'selected':'' ?>><?= $s ?></option>
                            <?php endforeach; ?>
                        </select>
                        <select name="dept" class="form-control" style="width:160px;" onchange="this.form.submit()">
                            <option value="">All Departments</option>
                            <?php foreach ($dept_list as $did => $dname): ?>
                            <option value="<?= $did ?>" <?= $filter_dept===$did?'selected':'' ?>><?= htmlspecialchars($dname) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                        <a href="/hmsystem/appointments/index.php" class="btn btn-secondary"><i class="fas fa-times"></i> Clear</a>
                    </form>
                </div>

                <div class="table-wrapper">
                    <table>
                        <thead><tr>
                            <th>Appt ID</th><th>Patient</th><th>Department</th><th>Doctor</th>
                            <th>Date & Time</th><th>Purpose</th><th>Status</th><th>Actions</th>
                        </tr></thead>
                        <tbody>
                        <?php if ($appointments->num_rows === 0): ?>
                        <tr><td colspan="8"><div class="empty-state"><i class="fas fa-calendar-xmark"></i><h4>No appointments found</h4><p>Create a new appointment to get started.</p></div></td></tr>
                        <?php else: ?>
                        <?php while ($a = $appointments->fetch_assoc()): ?>
                        <tr>
                            <td><span class="fw-600 text-primary"><?= htmlspecialchars($a['appointment_id']) ?></span></td>
                            <td>
                                <div class="fw-600"><?= htmlspecialchars($a['patient_name']) ?></div>
                                <div class="text-muted text-small"><?= htmlspecialchars($a['pid']) ?></div>
                            </td>
                            <td><?= htmlspecialchars($a['dept_name']) ?></td>
                            <td><?= htmlspecialchars($a['doctor_name'] ?: '—') ?></td>
                            <td>
                                <div><?= date('M d, Y', strtotime($a['appointment_date'])) ?></div>
                                <div class="text-muted text-small"><?= date('h:i A', strtotime($a['appointment_time'])) ?></div>
                            </td>
                            <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars($a['purpose']) ?>"><?= htmlspecialchars($a['purpose'] ?: '—') ?></td>
                            <td><span class="badge badge-<?= $status_colors[$a['status']] ?? 'secondary' ?>"><?= $a['status'] === 'Cancelled' ? 'Declined' : $a['status'] ?></span></td>
                            <td class="actions-cell">
                                <a href="?action=view&id=<?= $a['id'] ?>" class="btn btn-sm btn-outline" title="View Details">
                                    <i class="fas fa-eye"></i> View
                                </a>
                                <?php if (!$is_patient && $a['status'] === 'Pending'): ?>
                                <button type="button" class="btn btn-sm btn-success" title="Approve Appointment" onclick="openApproveModal(<?= $a['id'] ?>, '<?= htmlspecialchars(addslashes($a['appointment_id'])) ?>', '<?= htmlspecialchars(addslashes($a['patient_name'])) ?>')">
                                    <i class="fas fa-check"></i> Approve
                                </button>
                                <button type="button" class="btn btn-sm btn-danger" title="Decline Appointment" onclick="openDeclineModal(<?= $a['id'] ?>, '<?= htmlspecialchars(addslashes($a['appointment_id'])) ?>', '<?= htmlspecialchars(addslashes($a['patient_name'])) ?>')">
                                    <i class="fas fa-times"></i> Decline
                                </button>
                                <?php elseif (!$is_patient && $a['status'] === 'Scheduled'): ?>
                                <button type="button" class="btn btn-sm btn-danger" title="Decline Appointment" onclick="openDeclineModal(<?= $a['id'] ?>, '<?= htmlspecialchars(addslashes($a['appointment_id'])) ?>', '<?= htmlspecialchars(addslashes($a['patient_name'])) ?>')">
                                    <i class="fas fa-times"></i> Decline
                                </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($total_pages > 1): ?>
                <div style="padding:16px 24px;">
                    <div class="pagination">
                        <?php for ($i=1;$i<=$total_pages;$i++): ?>
                        <a href="?page=<?=$i?>&search=<?=urlencode($search)?>&status=<?=urlencode($filter_status)?>&dept=<?=$filter_dept?>&date=<?=urlencode($filter_date)?>"
                           class="page-link <?=$i===$page_num?'active':''?>"><?=$i?></a>
                        <?php endfor; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h4><i class="fas fa-calendar-plus"></i> New Appointment</h4>
            <button class="modal-close" onclick="closeModal('addModal')"><i class="fas fa-times"></i></button>
        </div>
        <form method="POST">
        <input type="hidden" name="form_action" value="add">
        <div class="modal-body">
            <div class="form-grid form-grid-2">
                <?php if ($is_patient): ?>
                <div class="col-span-2" style="background: var(--bg-cream-box); border: 1px solid var(--border-color); border-radius: var(--radius-sm); padding: 12px 16px; display: flex; align-items: center; justify-content: space-between;">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <div style="width: 38px; height: 38px; border-radius: 50%; background: var(--primary-red); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px;">
                            <?= strtoupper(substr($_SESSION['full_name'] ?? 'P', 0, 1)) ?>
                        </div>
                        <div>
                            <div style="font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-muted); font-weight: 600;">Booking Patient</div>
                            <div style="font-size: 14.5px; font-weight: 700; color: var(--navy-dark);"><?= htmlspecialchars($_SESSION['full_name']) ?></div>
                        </div>
                    </div>
                    <span class="badge badge-success" style="font-size: 11.5px;"><i class="fas fa-check-circle"></i> Verified Patient</span>
                </div>
                <input type="hidden" name="patient_id" value="<?= $my_patient_id ?>">
                <input type="hidden" name="status" value="Pending">

                <div class="form-group">
                    <label class="form-label">Department <span class="text-danger">*</span></label>
                    <select name="department_id" class="form-control" required style="width: 100%;">
                        <option value="">Select Department</option>
                        <?php foreach ($dept_list as $id => $name): ?>
                        <option value="<?=$id?>"><?=htmlspecialchars($name)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Doctor / Attending Physician <span class="text-danger">*</span></label>
                    <select name="doctor_name" class="form-control" required style="width: 100%;">
                        <option value="">Select Doctor</option>
                        <?php foreach ($doctors_list as $doc): ?>
                        <option value="<?= htmlspecialchars($doc) ?>"><?= htmlspecialchars($doc) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                <div class="form-group">
                    <label class="form-label">Patient <span class="text-danger">*</span></label>
                    <select name="patient_id" class="form-control" required style="width: 100%;">
                        <option value="">Select Patient</option>
                        <?php foreach ($pt_list as $id => $name): ?>
                        <option value="<?=$id?>"><?=htmlspecialchars($name)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Department <span class="text-danger">*</span></label>
                    <select name="department_id" class="form-control" required style="width: 100%;">
                        <option value="">Select Department</option>
                        <?php foreach ($dept_list as $id => $name): ?>
                        <option value="<?=$id?>"><?=htmlspecialchars($name)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Doctor / Attending Physician <span class="text-danger">*</span></label>
                    <select name="doctor_name" class="form-control" required style="width: 100%;" onchange="updateOccupiedSlots('addModal')">
                        <option value="">Select Doctor</option>
                        <?php foreach ($doctors_list as $doc): ?>
                        <option value="<?= htmlspecialchars($doc) ?>"><?= htmlspecialchars($doc) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control" style="width: 100%;">
                        <option value="Pending">Pending</option>
                        <option value="Scheduled">Scheduled</option>
                    </select>
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label">Appointment Date <span class="text-danger">*</span></label>
                    <input type="date" name="appointment_date" min="<?=date('Y-m-d')?>" class="form-control" required value="<?=date('Y-m-d')?>" style="width: 100%;" onchange="updateOccupiedSlots('addModal')">
                    <small class="text-muted"><i class="fas fa-lock"></i> Past dates are disabled</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Appointment Time (Fixed Slots) <span class="text-danger">*</span></label>
                    <select name="appointment_time" class="form-control" required style="width: 100%;">
                        <option value="">Select Schedule Slot</option>
                        <?php foreach ($schedule_slots as $t_val => $t_lbl): ?>
                        <option value="<?=$t_val?>" data-base="<?=$t_lbl?>"><?=$t_lbl?></option>
                        <?php endforeach; ?>
                    </select>
                    <small id="slotNoticeAdd" style="color:var(--text-muted);font-size:11.5px;margin-top:4px;display:block;">Occupied slots will be disabled</small>
                </div>

                <div class="form-group col-span-2">
                    <label class="form-label">Purpose / Reason for Visit</label>
                    <textarea name="purpose" class="form-control" rows="2" placeholder="Describe the purpose of the appointment..." style="width: 100%;"></textarea>
                </div>
                <div class="form-group col-span-2">
                    <label class="form-label">Notes</label>
                    <input type="text" name="notes" class="form-control" placeholder="Additional notes..." style="width: 100%;">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Cancel</button>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Create Appointment</button>
        </div>
        </form>
    </div>
</div>

<!-- VIEW / EDIT MODALS -->
<?php if ($view_appt && $action === 'view'): ?>
<div class="modal-overlay active" id="viewModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h4><i class="fas fa-calendar-check"></i> Appointment Details — <?= htmlspecialchars($view_appt['appointment_id']) ?></h4>
            <a href="/hmsystem/appointments/index.php" class="modal-close"><i class="fas fa-times"></i></a>
        </div>
        <div class="modal-body">
            <div class="info-grid">
                <div class="info-item"><div class="label">Appointment ID</div><div class="value text-primary fw-600"><?= htmlspecialchars($view_appt['appointment_id']) ?></div></div>
                <div class="info-item"><div class="label">Patient</div><div class="value"><?= htmlspecialchars($view_appt['patient_name']) ?> (<?= htmlspecialchars($view_appt['pid']) ?>)</div></div>
                <div class="info-item"><div class="label">Department</div><div class="value"><?= htmlspecialchars($dept_list[$view_appt['department_id']] ?? '—') ?></div></div>
                <div class="info-item"><div class="label">Doctor</div><div class="value"><?= htmlspecialchars($view_appt['doctor_name'] ?: '—') ?></div></div>
                <div class="info-item"><div class="label">Date</div><div class="value"><?= date('F d, Y', strtotime($view_appt['appointment_date'])) ?></div></div>
                <div class="info-item"><div class="label">Time</div><div class="value"><?= date('h:i A', strtotime($view_appt['appointment_time'])) ?></div></div>
                <div class="info-item"><div class="label">Status</div><div class="value"><span class="badge badge-<?= $status_colors[$view_appt['status']] ?? 'secondary' ?>"><?= $view_appt['status'] ?></span></div></div>
                <div class="info-item" style="grid-column:1/-1;"><div class="label">Purpose</div><div class="value"><?= htmlspecialchars($view_appt['purpose'] ?: '—') ?></div></div>
                <?php if ($view_appt['notes']): ?><div class="info-item" style="grid-column:1/-1;"><div class="label">Notes</div><div class="value"><?= htmlspecialchars($view_appt['notes']) ?></div></div><?php endif; ?>
            </div>
        </div>
        <div class="modal-footer">
            <a href="/hmsystem/appointments/index.php" class="btn btn-secondary">Close</a>
            <?php if ($view_appt['status'] === 'Pending' && !$is_patient): ?>
            <button type="button" class="btn btn-success" onclick="openApproveModal(<?= $view_appt['id'] ?>, '<?= htmlspecialchars(addslashes($view_appt['appointment_id'])) ?>', '<?= htmlspecialchars(addslashes($view_appt['patient_name'])) ?>')"><i class="fas fa-check"></i> Approve Appointment</button>
            <button type="button" class="btn btn-danger" onclick="openDeclineModal(<?= $view_appt['id'] ?>, '<?= htmlspecialchars(addslashes($view_appt['appointment_id'])) ?>', '<?= htmlspecialchars(addslashes($view_appt['patient_name'])) ?>')"><i class="fas fa-times"></i> Decline Appointment</button>
            <?php elseif ($view_appt['status'] === 'Scheduled' && !$is_patient): ?>
            <button type="button" class="btn btn-danger" onclick="openDeclineModal(<?= $view_appt['id'] ?>, '<?= htmlspecialchars(addslashes($view_appt['appointment_id'])) ?>', '<?= htmlspecialchars(addslashes($view_appt['patient_name'])) ?>')"><i class="fas fa-times"></i> Decline Appointment</button>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if ($view_appt && $action === 'edit'): ?>
<div class="modal-overlay active" id="editModal">
    <div class="modal modal-lg">
        <div class="modal-header">
            <h4><i class="fas fa-calendar-pen"></i> Edit Appointment — <?= htmlspecialchars($view_appt['appointment_id']) ?></h4>
            <a href="/hmsystem/appointments/index.php" class="modal-close"><i class="fas fa-times"></i></a>
        </div>
        <form method="POST">
        <input type="hidden" name="form_action" value="edit">
        <input type="hidden" name="edit_id" value="<?= $view_appt['id'] ?>">
        <div class="modal-body">
            <div class="form-grid form-grid-2">
                <div class="form-group">
                    <label class="form-label">Patient <span class="text-danger">*</span></label>
                    <select name="patient_id" class="form-control" required style="width: 100%;">
                        <?php foreach ($pt_list as $id => $name): ?>
                        <option value="<?=$id?>" <?=$view_appt['patient_id']==$id?'selected':''?>><?=htmlspecialchars($name)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Department <span class="text-danger">*</span></label>
                    <select name="department_id" class="form-control" required style="width: 100%;">
                        <?php foreach ($dept_list as $id => $name): ?>
                        <option value="<?=$id?>" <?=$view_appt['department_id']==$id?'selected':''?>><?=htmlspecialchars($name)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Doctor / Attending Physician <span class="text-danger">*</span></label>
                    <select name="doctor_name" class="form-control" required style="width: 100%;" onchange="updateOccupiedSlots('editModal', <?=$view_appt['id']?>)">
                        <option value="">Select Doctor</option>
                        <?php foreach ($doctors_list as $doc): ?>
                        <option value="<?= htmlspecialchars($doc) ?>" <?= (($view_appt['doctor_name']??'') === $doc) ? 'selected' : '' ?>><?= htmlspecialchars($doc) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control" style="width: 100%;">
                        <?php foreach (['Pending','Scheduled','Completed','Cancelled'] as $s): ?>
                        <option value="<?=$s?>" <?=$view_appt['status']===$s?'selected':''?>><?=$s?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Appointment Date <span class="text-danger">*</span></label>
                    <input type="date" name="appointment_date" min="<?=date('Y-m-d')?>" class="form-control" required value="<?=$view_appt['appointment_date']?>" style="width: 100%;" onchange="updateOccupiedSlots('editModal', <?=$view_appt['id']?>)">
                    <small class="text-muted"><i class="fas fa-lock"></i> Past dates are disabled</small>
                </div>
                <div class="form-group">
                    <label class="form-label">Appointment Time (Fixed Slots) <span class="text-danger">*</span></label>
                    <select name="appointment_time" class="form-control" required style="width: 100%;">
                        <option value="">Select Schedule Slot</option>
                        <?php foreach ($schedule_slots as $t_val => $t_lbl): ?>
                        <option value="<?=$t_val?>" data-base="<?=$t_lbl?>" <?=(substr($view_appt['appointment_time'],0,5)===substr($t_val,0,5))?'selected':''?>><?=$t_lbl?></option>
                        <?php endforeach; ?>
                    </select>
                    <small id="slotNoticeEdit" style="color:var(--text-muted);font-size:11.5px;margin-top:4px;display:block;">Occupied slots will be disabled</small>
                </div>
                <div class="form-group col-span-2">
                    <label class="form-label">Purpose / Reason for Visit</label>
                    <textarea name="purpose" class="form-control" rows="2" placeholder="Describe the purpose of the appointment..." style="width: 100%;"><?=htmlspecialchars($view_appt['purpose']??'')?></textarea>
                </div>
                <div class="form-group col-span-2">
                    <label class="form-label">Notes</label>
                    <input type="text" name="notes" class="form-control" placeholder="Additional notes..." value="<?=htmlspecialchars($view_appt['notes']??'')?>" style="width: 100%;">
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <a href="/hmsystem/appointments/index.php" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Changes</button>
        </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- APPROVE APPOINTMENT CONFIRMATION MODAL -->
<div class="modal-overlay" id="approveModal">
    <div class="modal" style="max-width: 470px; text-align: center; padding: 28px 24px; border-radius: 14px;">
        <div style="width: 58px; height: 58px; border-radius: 50%; background: #ecfdf5; color: #059669; display: flex; align-items: center; justify-content: center; font-size: 26px; margin: 0 auto 16px; border: 2px solid #a7f3d0;">
            <i class="fas fa-calendar-check"></i>
        </div>
        <h3 style="margin: 0 0 10px; font-size: 20px; color: var(--navy-dark); font-weight: 700;">Approve Appointment?</h3>
        <p style="color: var(--text-muted); font-size: 14px; line-height: 1.5; margin: 0 0 24px;" id="approveModalText">
            Are you sure you want to approve this appointment? Status will be set to Scheduled.
        </p>
        <div style="display: flex; gap: 12px; justify-content: center;">
            <button type="button" class="btn btn-secondary" onclick="closeModal('approveModal')" style="padding: 10px 22px;">Cancel</button>
            <a href="#" id="approveConfirmBtn" class="btn btn-success" style="padding: 10px 24px; font-weight: 600;">
                <i class="fas fa-check"></i> Yes, Approve
            </a>
        </div>
    </div>
</div>

<!-- DECLINE APPOINTMENT CONFIRMATION MODAL -->
<div class="modal-overlay" id="declineModal">
    <div class="modal" style="max-width: 470px; text-align: center; padding: 28px 24px; border-radius: 14px;">
        <div style="width: 58px; height: 58px; border-radius: 50%; background: #fef2f2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 26px; margin: 0 auto 16px; border: 2px solid #fecaca;">
            <i class="fas fa-calendar-times"></i>
        </div>
        <h3 style="margin: 0 0 10px; font-size: 20px; color: var(--navy-dark); font-weight: 700;">Decline Appointment?</h3>
        <p style="color: var(--text-muted); font-size: 14px; line-height: 1.5; margin: 0 0 24px;" id="declineModalText">
            Are you sure you want to decline this appointment? Status will be set to Declined.
        </p>
        <div style="display: flex; gap: 12px; justify-content: center;">
            <button type="button" class="btn btn-secondary" onclick="closeModal('declineModal')" style="padding: 10px 22px;">Cancel</button>
            <a href="#" id="declineConfirmBtn" class="btn btn-danger" style="padding: 10px 24px; font-weight: 600;">
                <i class="fas fa-times"></i> Yes, Decline
            </a>
        </div>
    </div>
</div>

<script>
const bookedSlots = <?=json_encode($booked_slots)?>;

function openModal(id) { 
    const el = document.getElementById(id);
    if (el) {
        el.classList.add('active'); 
        if (id === 'addModal') updateOccupiedSlots('addModal');
        if (id === 'editModal') {
            const editIdInp = el.querySelector('input[name="edit_id"]');
            const eid = editIdInp ? parseInt(editIdInp.value) : 0;
            updateOccupiedSlots('editModal', eid);
        }
    }
}
function closeModal(id) { 
    const el = document.getElementById(id);
    if (el) el.classList.remove('active'); 
}

function openApproveModal(id, apptCode, patientName) {
    document.getElementById('approveModalText').innerHTML = 'Are you sure you want to approve appointment <strong style="color:var(--primary); font-size:15px;">' + apptCode + '</strong>' + (patientName ? ' for <strong>' + patientName + '</strong>' : '') + '? Status will be set to <strong>Scheduled</strong>.';
    document.getElementById('approveConfirmBtn').href = '?action=approve&id=' + id;
    openModal('approveModal');
}

function openDeclineModal(id, apptCode, patientName) {
    document.getElementById('declineModalText').innerHTML = 'Are you sure you want to decline appointment <strong style="color:var(--danger); font-size:15px;">' + apptCode + '</strong>' + (patientName ? ' for <strong>' + patientName + '</strong>' : '') + '? Status will be set to <strong>Declined</strong>.';
    document.getElementById('declineConfirmBtn').href = '?action=decline&id=' + id;
    openModal('declineModal');
}

function updateOccupiedSlots(modalId, currentApptId = 0) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    const docSelect = modal.querySelector('select[name="doctor_name"]');
    const dateInput = modal.querySelector('input[name="appointment_date"]');
    const timeSelect = modal.querySelector('select[name="appointment_time"]');
    if (!docSelect || !dateInput || !timeSelect) return;

    const doc = docSelect.value.trim();
    const date = dateInput.value.trim();
    if (!doc || !date) return;

    const key = doc + '|' + date;
    const taken = bookedSlots[key] || [];

    let occupiedCount = 0;
    for (let opt of timeSelect.options) {
        if (!opt.value) continue;
        const optVal = opt.value;
        const optShort = optVal.substring(0, 5);
        const base = opt.getAttribute('data-base') || opt.textContent.split(' — ')[0];
        opt.setAttribute('data-base', base);

        const isTaken = taken.some(t => (t.time === optShort || t.time_full === optVal) && t.id !== currentApptId);
        if (isTaken) {
            occupiedCount++;
            opt.disabled = true;
            opt.textContent = base + ' — [OCCUPIED / TAKEN]';
            opt.style.color = '#dc2626';
            if (timeSelect.value === optVal) {
                timeSelect.value = '';
            }
        } else {
            opt.disabled = false;
            opt.textContent = base;
            opt.style.color = '';
        }
    }

    const notice = modal.querySelector(modalId === 'addModal' ? '#slotNoticeAdd' : '#slotNoticeEdit');
    if (notice) {
        if (occupiedCount > 0) {
            notice.innerHTML = `<span style="color:#dc2626;font-weight:600;"><i class="fas fa-ban"></i> ${occupiedCount} slot(s) already occupied for ${doc} on this date. Bawal na pong kunin.</span>`;
        } else {
            notice.innerHTML = `<span style="color:#059669;font-weight:600;"><i class="fas fa-check-circle"></i> All schedule slots are available for ${doc} on this date.</span>`;
        }
    }
}

document.querySelectorAll('.modal-overlay').forEach(el => {
    el.addEventListener('click', function(e) { if (e.target === el) closeModal(el.id); });
});
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'new') {
        openModal('addModal');
    }
    const editModal = document.getElementById('editModal');
    if (editModal && editModal.classList.contains('active')) {
        const editIdInp = editModal.querySelector('input[name="edit_id"]');
        const eid = editIdInp ? parseInt(editIdInp.value) : 0;
        updateOccupiedSlots('editModal', eid);
    }
});
</script>
<script src="/hmsystem/assets/js/main.js"></script>
</body>
</html>
<?php $conn->close(); ?>
